@extends('layouts.master')


@section('contenido')
<div class="right custom-social">
    <a href="{{URL::to('https://twitter.com/home')}}"><img class='twitter' src={{asset('imagenes/twitter.png')}} alt="Twitter"></a>
    <a href="{{URL::to('https://www.facebook.com/maria.acostaprieto.3')}}"><img class='facebook' src={{asset('imagenes/facebook.png')}} alt="Facebook"></a>
    <a href="{{URL::to('https://www.instagram.com/?hl=es')}}"><img class='instagram' src={{asset('imagenes/instagram.png')}} alt="Instagram"></a>
</div>
<div>    <!--class="flex-center position-ref full-height"-->
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Iniciar sesión</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Registrarse</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    El armario de Maria
                </div>
                <nav><ul>
                    <li><a href="{{ url('index') }}">Inicio</a></li>
                     <li><a href="#">Categorias</a>
                        <ul><li><a href="{{ url('belleza') }}">Belleza</a></li>
                            <li><a href="{{ url('moda') }}">Moda</a></li>
                        </ul>
                    </li>
                    <li><a href="{{ url('acercade') }}">Acerca de</a></li>
                    <li><a href="{{ url('contacto') }}">Contacto</a></li>
             </ul>
             </nav>
        </div>
<h1>PIEL LIMPIA Y FRESCA</h1>
<div class="wp-block-image">
    <img src="{{ asset('imagenes/fotos/nivea.jpg') }}" alt="" width="400" height="400">
    <p>Una rutina de belleza diaria importante (quizás la más importante) para mí es limpiar bien mi piel.
     Es muy importante para una piel saludable y, cuando la limpia adecuadamente, todas las cremas faciales 
     y sueros funcionan de una manera completamente diferente. 
     </p>
    <p>
    Aguas micelares, ¿probablemente has oído hablar de ellas antes? Están hechos para limpiar tu rostro
     y eliminar el maquillaje, son ligeros pero efectivos. Creo que estos son un invento tan brillante, 
     que honestamente uso un agua micelar diariamente. A veces lo uso después de un gel limpiador, 
     y termino como tóner para asegurarme de que mi limpieza esté 100% limpia, pero a menudo solo alcanzo 
     el agua micelar.
    </p>
    <p>
    ¿Qué te parecen las aguas micelares? ¿Los has probado?
    </p>
</div>