@extends('layouts.master')


@section('contenido')
<div class="right custom-social">
    <a href="{{URL::to('https://twitter.com/home')}}"><img class='twitter' src={{asset('imagenes/twitter.png')}} alt="Twitter"></a>
    <a href="{{URL::to('https://www.facebook.com/maria.acostaprieto.3')}}"><img class='facebook' src={{asset('imagenes/facebook.png')}} alt="Facebook"></a>
    <a href="{{URL::to('https://www.instagram.com/?hl=es')}}"><img class='instagram' src={{asset('imagenes/instagram.png')}} alt="Instagram"></a>
</div>
<div>    <!--class="flex-center position-ref full-height"-->
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Iniciar sesión</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Registrarse</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    El armario de Maria
                </div>
                <nav><ul>
                    <li><a href="{{ url('index') }}">Inicio</a></li>
                     <li><a href="#">Categorias</a>
                        <ul><li><a href="{{ url('belleza') }}">Belleza</a></li>
                            <li><a href="{{ url('moda') }}">Moda</a></li>
                        </ul>
                    </li>
                    <li><a href="{{ url('acercade') }}">Acerca de</a></li>
                    <li><a href="{{ url('contacto') }}">Contacto</a></li>
             </ul>
             </nav>
        </div>
<h1>3 CONSEJOS PARA COMENZAR BIEN EL DIA</h1>
<div class="wp-block-image">
    <img src="{{ asset('imagenes/fotos/desayuno.jpg') }}" alt="" width="400" height="350">
    <p>
    Como he mencionado antes, soy una persona mañanera. No siempre ha sido así, pero después de aprender 
    a ser uno, no puedo imaginar volver. Las mañanas son el mejor momento del día, es cuando me siento más 
    inspirado y lleno de energía. Para mí, ser una persona madrugadora está conectado a vivir más 
    saludablemente y tener un estilo de vida equilibrado. Después de vivir el verano de manera descuidada,
    ha sido muy refrescante volver a ciertas rutinas: cuidarme mejor y sentirme más fresco. 
    </p>

    <img src="{{ asset('imagenes/fotos/piedra.jpg') }}" alt="" width="400" height="350">
    <p>
    1. Comience su mañana la noche anterior.
     He hablado sobre esto antes, todo realmente comienza la noche anterior. 
     Todos pueden tener sus propios preparativos, para mí es limpiar mi casa, aclarar mi mente y 
     despejar del trabajo y tomándolo con calma antes de irme a la cama. 
     La preparación es la clave, desea tener una mañana libre de estrés, 
    como si pudiera comenzar cada día con un cuerpo y una mente relajados.
    </p>
    <p>
    2. Refréscate y cuídate. Siempre quiero comenzar el día sintiéndome fresco:
     una ducha fría, agua hidratante y potable, piel clara e hidratada, en general una sensación de limpieza. 
     Para mí esa es la base de todo, te sientes unido incluso sin maquillaje si solo tienes una base fresca.
     He usado este refuerzo VICHY MINÉRAL 89 ahora durante aproximadamente un mes, y ha sido una
     muy buena adición a mi rutina de cuidado de la piel. Especialmente después del verano,
     cuando mi piel generalmente se vuelve más seca. Hasta ahora he logrado evitar toda la sequedad, 
     ¡así que mi rutina de cuidado de la piel ha estado funcionando! Aplico este refuerzo diariamente 
      antes de cualquier suero o humectante.
    </p>
    <p>
    3. Sal afuera. Es posible que hayas visto venir esto, ¿verdad? 
    Después de que Minnie saliera por la mañana realmente se ha convertido en un hábito diario,
     y me encanta. Comenzar el día con aire fresco, es la mejor manera de despertar tu cuerpo. 
     
     (Además del café, pero tener ambos es la perfección).
    </p>
</div>