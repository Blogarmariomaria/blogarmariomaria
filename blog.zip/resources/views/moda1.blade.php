@extends('layouts.master')


@section('contenido')
<div class="right custom-social">
    <a href="{{URL::to('https://twitter.com/home')}}"><img class='twitter' src={{asset('imagenes/twitter.png')}} alt="Twitter"></a>
    <a href="{{URL::to('https://www.facebook.com/maria.acostaprieto.3')}}"><img class='facebook' src={{asset('imagenes/facebook.png')}} alt="Facebook"></a>
    <a href="{{URL::to('https://www.instagram.com/?hl=es')}}"><img class='instagram' src={{asset('imagenes/instagram.png')}} alt="Instagram"></a>
</div>
<div>    <!--class="flex-center position-ref full-height"-->
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Iniciar sesión</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Registrarse</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    El armario de Maria
                </div>
                <nav><ul>
                    <li><a href="{{ url('index') }}">Inicio</a></li>
                     <li><a href="#">Categorias</a>
                        <ul><li><a href="{{ url('belleza') }}">Belleza</a></li>
                            <li><a href="{{ url('moda') }}">Moda</a></li>
                        </ul>
                    </li>
                    <li><a href="{{ url('acercade') }}">Acerca de</a></li>
                    <li><a href="{{ url('contacto') }}">Contacto</a></li>
             </ul>
             </nav>
        </div>
<h1 id="moda1">3 COSAS QUE ME HACEN FELIZ AHORA MISMO</h1>
<div class="wp-block-image">
    <img src="{{ asset('imagenes/fotos/niños.jpg') }}" alt="" width="500" height="350">
    <p>En esta foto os presento a mis dos primos. La niña se llama Vega y tiene 4 años, y el niño se llama
    Luca y tiene 1 año.
    Estas dos personas son las mas importantes de mi vida. Con tan solo 19 años me hicieron madrina de Vega,
    la noticia me llego por sorpresa en navidades. Ese era mi regalo de navidad y que mejor regalo.
    Esta sesion de fotos se la hicieron hace un mes en un estudio de una chica de mi prueblo.</p>

    <img src="{{ asset('imagenes/fotos/viaje.jpg') }}" alt="" width="500" height="350">
    <p>El año que entra, en 2020, quiero hacerme un viaje a Africa. Nada mas y nada menos que a los campos de 
    refugiados.
    Se que es un locura y que me podria hacer un viaje diez mil veces mejor pero quiero vivir esa experiencia
    y aprender de las personas que viven alli.
    Este sueño lo llevo queriendo hacer hace 2 años aproximadamente, pero quizas por estudios y trabajo no se 
    ha podido realizar.
    Pero si blogeros este año que entra me voy a hacer el viaje de mis sueños. ¡OS LO CONTARE!</p>

    <img src="{{ asset('imagenes/fotos/navidad.jpe') }}" alt="" width="500" height="350">
    <p>Se acerca la epoca mas feliz y mas triste del año. Mas feliz porque nos juntamos todos los seres queridos
    en la misma mesa, la mejor excusa para estar y reir cerca de los tuyos. La mas triste porque hay personas
    que ya no se sientan en esa mesa a celebrarlo con nosotros, y sin ellos la navidad se apaga un poco.
    Menos mal que la ilusion de los mas pequeños de la casa no se pierde y nos hacen vivirla de tal manera 
    que nos contagian esa alegria y nos hacen sentir la ilusion que alguna vez perdimos.</p>
</div>