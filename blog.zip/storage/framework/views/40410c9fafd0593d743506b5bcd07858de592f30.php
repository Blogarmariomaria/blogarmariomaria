<!--Pie de página-->
<footer>
        <a rel="nofollow" href="#" onclick="window.scrollTo(0,0); return false;">
        Volver arriba</a>
        <span class="copyright">Copyright © 2019 Maria / Maria Acosta</span>
       
</footer><?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>