<?php $__env->startSection('contenido'); ?>
<div class="right custom-social">
    <a href="<?php echo e(URL::to('https://twitter.com/home')); ?>"><img class='twitter' src=<?php echo e(asset('imagenes/twitter.png')); ?> alt="Twitter"></a>
    <a href="<?php echo e(URL::to('https://www.facebook.com/maria.acostaprieto.3')); ?>"><img class='facebook' src=<?php echo e(asset('imagenes/facebook.png')); ?> alt="Facebook"></a>
    <a href="<?php echo e(URL::to('https://www.instagram.com/?hl=es')); ?>"><img class='instagram' src=<?php echo e(asset('imagenes/instagram.png')); ?> alt="Instagram"></a>
</div>
<div>    <!--class="flex-center position-ref full-height"-->
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Iniciar sesión</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Registrarse</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    El armario de Maria
                </div>
                <nav><ul>
                    <li><a href="<?php echo e(url('index')); ?>">Inicio</a></li>
                     <li><a href="#">Categorias</a>
                        <ul><li><a href="<?php echo e(url('belleza')); ?>">Belleza</a></li>
                            <li><a href="<?php echo e(url('moda')); ?>">Moda</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('acercade')); ?>">Acerca de</a></li>
                    <li><a href="<?php echo e(url('contacto')); ?>">Contacto</a></li>
             </ul>
             </nav>
        </div>
<h1  id="moda1">LO QUE HICE ESTE FIN DE SEMANA</h1>
<div class="wp-block-image">
    <img src="<?php echo e(asset('imagenes/fotos/amigos.jpg')); ?>" alt="" width="300" height="400">
    <p>Este fin de semana se inaguro la pista de hielo en mi pueblo, por lo que fuimos a verla. Ya nos tocara
    estrenarla y partinar.
    Despues quedamos un par de amigos que hacia mucho que nos veiamos para cenar y hablar, de eso que hablan 
    los amigos de los tiempos vividos y de los que nos quedan por vivir.
    No hay mejor manera de pasar un puente que junto la familia que se elige. GRACIAS A ESTA FAMILIA</p>
</div>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/moda2.blade.php ENDPATH**/ ?>