<?php $__env->startSection('contenido'); ?>
<div class="right custom-social">
    <a href="<?php echo e(URL::to('https://twitter.com/home')); ?>"><img class='twitter' src=<?php echo e(asset('imagenes/twitter.png')); ?> alt="Twitter"></a>
    <a href="<?php echo e(URL::to('https://www.facebook.com/maria.acostaprieto.3')); ?>"><img class='facebook' src=<?php echo e(asset('imagenes/facebook.png')); ?> alt="Facebook"></a>
    <a href="<?php echo e(URL::to('https://www.instagram.com/?hl=es')); ?>"><img class='instagram' src=<?php echo e(asset('imagenes/instagram.png')); ?> alt="Instagram"></a>
</div>
<div>    <!--class="flex-center position-ref full-height"-->
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Iniciar sesión</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Registrarse</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    El armario de Maria
                </div>
                <nav><ul>
                    <li><a href="<?php echo e(url('index')); ?>">Inicio</a></li>
                     <li><a href="#">Categorias</a>
                        <ul><li><a href="<?php echo e(url('belleza')); ?>">Belleza</a></li>
                            <li><a href="<?php echo e(url('moda')); ?>">Moda</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('acercade')); ?>">Acerca de</a></li>
                    <li><a href="<?php echo e(url('contacto')); ?>">Contacto</a></li>
             </ul>
             </nav>
        </div>
<h1 id="moda">MODA</h1>
<div class="wp-block-image">
    <img src="<?php echo e(asset('imagenes/fotos/habitacion.jpg')); ?>" alt="" width="300" height="350">
    <p><a href="<?php echo e(url('moda1')); ?>" alt="3 cosas que me hacen feliz ahora mismo">
    3 cosas que me hacen feliz ahora mismo
    </p>
</div>
<div class="wp-block-image">
    <img src="<?php echo e(asset('imagenes/fotos/habitacion.jpg')); ?>" alt="" width="300" height="350">
    <p><a href="<?php echo e(url('moda2')); ?>" alt="lo que hice este fin de semana">
    Lo que hice este fin de semana
    </p>
</div>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/moda.blade.php ENDPATH**/ ?>